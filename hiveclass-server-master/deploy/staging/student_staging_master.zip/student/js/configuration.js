define({
    application: {
        url: 'https://staging.hiveschool.aerohive.com/apps/student/'
    }
});

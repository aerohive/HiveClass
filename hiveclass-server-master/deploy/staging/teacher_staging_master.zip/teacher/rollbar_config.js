window.rollbarConfig = {
    accessToken: "9a6ea1bff98a4d0586f8892d55dd1ac1",
    environment: "staging"
};
